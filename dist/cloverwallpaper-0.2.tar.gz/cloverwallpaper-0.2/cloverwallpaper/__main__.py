#!/usr/bin/env python

import cloverwallpaper

if __name__ == '__main__':
    cloverwallpaper.main()

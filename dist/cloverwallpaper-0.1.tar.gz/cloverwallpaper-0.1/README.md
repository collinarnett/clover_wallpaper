# clover_wallpaper
A tool to download wallpapers from 4chan.
